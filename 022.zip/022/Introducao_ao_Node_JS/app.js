var app = require('./config/server');

app();
