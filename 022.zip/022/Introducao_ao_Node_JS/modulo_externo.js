//var teste = "meu módulo externo";

//module.exports = teste;


module.exports = function(){
  var teste = "meu módulo externo";
  return teste;
};
